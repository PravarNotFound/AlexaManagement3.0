# Calls Music Plus

### ![MusicsNexa_bot](https://telegra.ph/file/a4b7d13da17c3cc828ab9.jpg)


**A [CallsMusic](https://github.com/callsmusic/callsmusic) Based Telegram Bot and Userbot To Play Music in Your Telegram Groups With Some Cool Extra Features!**


## Note!⚠️ ,
_**You need another (dummy) Telegram Account To Use/Deploy This!**_

## Features 🔥️

- **Play Music In Telegram Group Voice Chats!** (Supports Multiple Groups)
- **Supports Queues!**
- **Control by buttons or commands**
- **Search For YouTube Videos Inline!**
- **Download Yt Songs By It's Name!**
- **Download Yt Videos By It's Name!**
- **Saavn Music Download**
- **Deezer Music Download**
- **Get Voice Chat Link!** (Public Groups Only )
- **Get Lyrics Of Your Song!**
- **Join & Leave Streamer Account Using A Command**
- **Ban / Unban Users and Check User Status.**
- **Broadcast Messages**
- **Quote Messages Like Quotely Bot!**
- **Delete Command Feature**
- **Update Your Bot Without Leaving Telegram**

**Please Refer [Command Explanation](https://itz-fork.gitbook.io/callsmusic-plus/about#command-explanation) to Know How To Use These Commands and Know More About Them!**


# Deployment
Before You Deploy make sure you Starred & Forked **[This Repo!](https://github.com/Itz-fork/Callsmusic-Plus)** 🤗️


## The Easy Way ⚡️

### With Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Itz-fork/Callsmusic-Plus)

### With Zeet
<a href="https://zeet.co/new/template/itz-fork/yeah-my-man"><img src="https://user-images.githubusercontent.com/77770753/119371372-fe917900-bcd3-11eb-8db5-f5e8063cdd1c.jpg" width="94" height="28"></a>


#### Get Pyrogram String Session
<a href="https://replit.com/@IamHirusha/GetPyroSessionVC"><img src="https://img.shields.io/badge/Run-Repl.it-white?style=for-the-badge&logo=repl.it"></a>


## Support!
Facing Problems While Deploying or Using? **[Read How To Deploy](https://itz-fork.gitbook.io/callsmusic-plus/deploying-the-bot)**
or Ask Me In **[Nexa Bots Support Group](https://t.me/Nexa_bots)**


# More Info
Read The **[Official Docs](https://itz-fork.gitbook.io/callsmusic-plus/)** For the Guides on How to Deploy and Getting Config Values.

<p align="center">
    <a href="https://itz-fork.gitbook.io/callsmusic-plus/"><img src="https://img.shields.io/badge/Docs-FAFAFA?style=for-the-badge&logo=gitbook&logoColor=black"></a> | <a href="https://github.com/Itz-fork/Callsmusic-Plus"><img src="https://img.shields.io/badge/GitHub-030202?style=for-the-badge&logo=github&logoColor=white"></a>
</p>

## Credits

- **[CallsMusic](https://github.com/callsmusic/callsmusic) ~ This is the base Repo! ❤️**
- **[Roj](https://github.com/rojserbest) & [Marvin](https://github.com/BlackStoneReborn)** : development
- **[Laky](https://github.com/Laky-64) & [Andrew](https://github.com/AndrewLaneX)** : PyTgCalls
- **Mr Dark prince**
- **TeamDaisyX**
- **TheHamkerCat**
- **Abirhasan2005**
- **DevsExpo**
- **N A C CREATIVE**: For Voice Chat Link Command!


## License

### GNU General Public License v3.0
[Read more](http://www.gnu.org/licenses/#GPL)
